<?php
  $title = "Lesson 01";
  $subtitle = "Introducing PHP";
  $toc_title = "Introducing PHP";
  $toc_items = [['Intro to PHP Syntax', 'php-syntax.php'], ['Static Grilled Cheese', 'static.html'], ['Dynamic Grilled Cheese', 'dynamic.php'], ['Lab 01 - Your Favourite Band', 'lab-01.php']];
?>

<?php include("../includes/header.php") ?>
<?php include("../includes/lesson-header.php") ?>
<?php include("../includes/table-of-contents.php") ?>
<?php include("../includes/footer.php") ?>