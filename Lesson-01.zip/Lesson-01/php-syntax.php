<!DOCTYPE html>
<html>

<head>
  <title>PHP Syntax</title>
</head>

<body>
  <header>
    <h1>PHP Syntax</h1>
  </header>

  <section>
    <h2>PHP Tags (block & inline) & Commenting</h2>
  </section>

  <section>
    <h2>Variables & Data Types</h2>
  </section>

  <section>
    <h2>Printing to the Screen (block & inline), Quotes, Concatenation & Interpolation</h2>
  </section>

  <section>
    <h2>Decision Structure</h2>
  </section>

  <section>
    <h2>Arrays & Hashes</h2>
  </section>

  <section>
    <h2>Repetition Structures</h2>
  </section>
</body>

</html>